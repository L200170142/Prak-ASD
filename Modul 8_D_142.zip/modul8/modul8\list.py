class Stack(object):
    def __init__(self):
        self.items =[]
    def isEmpty(self):
        return len(self)==0
    def __len__(self):
        return len(self.items)
    def peek(self):
        assert not self.isEmpy(), "Stack Kosong, Tidak Bisa DIINTIP!"
        return self.items[-1]
    def pop(self):
        assert not self.isEmpty(), "Stact kosong, Tidaak bisa DIPOP!!!"
        return self.items.pop()
    def push(self, data):
        self.items.append(data)

prompt = "masukan bilangan positif (<0 untuk mengakhiri):"
myStack = Stack()
value = int(input(prompt))
while value >= 0 :
    myStack.push(value)
    value = int(input(prompt))
while not myStack.isEmpty():
    value = myStack.pop()
    print(value)


